# -*- coding: utf-8 -*-
"""
Created on Thu Dec 27 15:22:41 2018

@author: INHA
"""


def hours():
    return 'Open 9-5 daily'

